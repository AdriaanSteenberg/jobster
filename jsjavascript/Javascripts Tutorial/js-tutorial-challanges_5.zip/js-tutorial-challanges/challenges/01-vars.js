/*
## Variables #1

1. create "firstName" and "last_name" variables
2. assign your values
3. create "address" variable and assign "main street" value to it
4. re-assign address to "first street" later
5. log all values in the console

*/

const firstName = "john";
const last_name = "smilga";

let address = "main street";
address = "first street";

console.log(firstName, last_name, address);
