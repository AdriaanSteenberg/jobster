# VS CODE SETUP

## EXTENSIONS

![Extensions](./extensions.png)
