## Position Property Project

#### Setup

- copy last project
- rename to (09-animation-property)
- change title (Animation Property)

#### HTML (structure)

- group h1 and p in div, with class .hero-text

#### CSS (styles)

- setup two animations (entering from top, bottom)
- add one to .hero-text, other to button
- values up to you
